this is template module. 
Please edit pom.xml and change <artifactId> to same as name of directory and your new module.
Also edit pom.xml in root directory and add your module there.